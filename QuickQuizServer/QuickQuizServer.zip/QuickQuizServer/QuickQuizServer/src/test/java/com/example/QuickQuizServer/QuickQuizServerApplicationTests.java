package com.example.QuickQuizServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickQuizServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
